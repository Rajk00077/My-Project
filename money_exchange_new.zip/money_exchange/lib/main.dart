import 'package:money_exchange/screens/home_page.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(ExchangeRateApp());
}

class ExchangeRateApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Exchange Rate App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}
