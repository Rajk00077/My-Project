import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String fromCurrency = "USD";
  String toCurrency = "INR";
  double inputAmount = 1.0;
  double convertedAmount = 0.0;
  bool isLoading = false;
  Map<String, dynamic>? exchangeRates;

  @override
  void initState() {
    super.initState();
    fetchExchangeRates();
  }

  Future<void> fetchExchangeRates() async {
    const apiUrl =
        'https://v6.exchangerate-api.com/v6/25ea652520b794fc1732a7f9/latest/USD';
    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      setState(() {
        exchangeRates = (data['conversion_rates'] as Map<String, dynamic>).map(
          (key, value) => MapEntry(key, value.toDouble()),
        );
        isLoading = false;
      });
    } else {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to fetch data')),
      );
    }
  }

  void calculateConversion() {
    if (//fromCurrency != null &&
        //toCurrency != null &&
        exchangeRates != null &&
        exchangeRates!.containsKey(fromCurrency) &&
        exchangeRates!.containsKey(toCurrency)) {
      double fromRate = exchangeRates![fromCurrency]!;
      double toRate = exchangeRates![toCurrency]!;
      setState(() {
        convertedAmount = inputAmount * (toRate / fromRate);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Currency Converter'),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : exchangeRates == null
              ? Center(
                  child: Text('Failed to load exchange rates'),
                )
              : Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      // Input Field for Amount
                      TextField(
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: 'Enter amount',
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (value) {
                          setState(() {
                            inputAmount = double.tryParse(value) ?? 0.0;
                            calculateConversion();
                          });
                        },
                      ),
                      const SizedBox(height: 20),

                      // Dropdown for From and To Currencies
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: exchangeRates!.containsKey(fromCurrency)
                                  ? fromCurrency
                                  : null,
                              items: exchangeRates!.keys
                                  .map<DropdownMenuItem<String>>((String key) {
                                return DropdownMenuItem<String>(
                                  value: key,
                                  child: Text(key),
                                );
                              }).toList(),
                              onChanged: (value) {
                                setState(() {
                                  fromCurrency = value!;
                                  calculateConversion();
                                });
                              },
                              decoration: InputDecoration(
                                labelText: 'From Currency',
                                border: OutlineInputBorder(),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Icon(Icons.swap_horiz, size: 30),
                          const SizedBox(width: 10),
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: exchangeRates!.containsKey(toCurrency)
                                  ? toCurrency
                                  : null,
                              items: exchangeRates!.keys
                                  .map<DropdownMenuItem<String>>((String key) {
                                return DropdownMenuItem<String>(
                                  value: key,
                                  child: Text(key),
                                );
                              }).toList(),
                              onChanged: (value) {
                                setState(() {
                                  toCurrency = value!;
                                  calculateConversion();
                                });
                              },
                              decoration: InputDecoration(
                                labelText: 'To Currency',
                                border: OutlineInputBorder(),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),

                      // Display Converted Amount
                      Text(
                        'Converted Amount: ${convertedAmount.toStringAsFixed(2)} $toCurrency',
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
    );
  }
}
